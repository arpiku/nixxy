module Main where

import qualified Nixxy 

main :: IO ()
main = do
  Nixxy.sayHello

