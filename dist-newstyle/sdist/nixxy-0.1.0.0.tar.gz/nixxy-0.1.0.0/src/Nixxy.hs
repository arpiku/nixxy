module Nixxy where

import qualified NixxySay

sayHello :: IO ()
sayHello = NixxySay.nixxySay "Hello I amm nixxy, here to help!"


